﻿// See https://aka.ms/new-console-template for more information
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace KerteszRubenDoga
{

    class Solsys
    {
        public string Nev { get; set; }
        public int HoldSzam { get; set; }
        public double Terfogat { get; set; }

        public Solsys(string v)
        {
            var tomb = v.Split(";");
            Nev = tomb[0];
            HoldSzam = int.Parse(tomb[1]);
            Terfogat = double.Parse(tomb[2]);
        }

        public override string ToString()
        {
            return $"Név: {Nev}; Holdak száma: {HoldSzam}; Térfogat: {Terfogat}";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;

            List<Solsys> bolygok = new List<Solsys>();

            foreach (var item in File.ReadAllLines(@"..\..\..\solsys.txt"))
            {
                bolygok.Add(new Solsys(item));
            }

            foreach (var item in bolygok)
            {
                Console.WriteLine(item);
            }

            double osszeg = 0;
            for (int i = 0; i < bolygok.Count; i++)
            {
                osszeg = osszeg + bolygok[i].HoldSzam;
            }

            double LegnagyobbTerfogat = bolygok[0].Terfogat;
            string LegnagyobbNev = bolygok[0].Nev;

            for (int i = 1; i < bolygok.Count; i++)
            {
                if (LegnagyobbTerfogat < bolygok[i].Terfogat)
                {
                    LegnagyobbTerfogat = bolygok[i].Terfogat;
                    LegnagyobbNev = bolygok[i].Nev;
                }
            }

            Console.WriteLine("3.feladat:" +
                $"\n\t 3.1: {bolygok.Count} bolygó van a naprendszerben" +
                $"\n\t 3.2: a naprendszerben egy bolygónak átlagosan {osszeg / bolygok.Count} holdja van" +
                $"\n\t 3.3: a legnagyobb térfogatú bolygó a {LegnagyobbNev}");
            Console.Write($"\t 3.4: írd be a keresett bolygó nevét: ");
            string BeirtNev = Console.ReadLine();

            int x = 0;
            bool van = false;
            while (x < bolygok.Count && !van)
            {
                if (BeirtNev == bolygok[x].Nev)
                {
                    van = true;
                }
                x++;
            }

            if (van)
            {
                Console.WriteLine("\tVan ilyen nevű bojgó a naprendszerben");
            }
            else
            {
                Console.WriteLine("\tsajnos nincs ilyen nevű bojgó a naprendszerben");
            }


            Console.Write("\tÍrj be egy egész számot: ");
            int bolygoSzam = Convert.ToInt32(Console.ReadLine());

            List<string> BolygoNev = new List<string>();

            for (int i = 0; i < bolygok.Count; i++)
            {
                if (bolygok[i].HoldSzam > bolygoSzam)
                {
                    BolygoNev.Add(bolygok[i].Nev);
                }
            }

            Console.WriteLine($"\t a következő bolygókanak van {bolygoSzam} nál/nél több holdja:" +
                $"[{BolygoNev}]");
        }
    }
}